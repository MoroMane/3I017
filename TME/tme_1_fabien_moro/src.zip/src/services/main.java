package services;

public class main {

	public static void main (String[] args) 
	{
		Operations resultat=new Operations();
		System.out.println(resultat.calcul(1,2,"addition"));
	}

}
